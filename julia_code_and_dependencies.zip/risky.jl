###############################
###############################
#######
####### risky.jl v1.0
#######   - Tom Buckley, tnbuckley@ucdavis.edu, November 2021
#######   - Julia code used in manuscript by Thomas N. Buckley, Ethan H. Frehner, and Brian N. Bailey, entitled
#######     "Optimal stomatal behavior is better represented by penalizing dynamic and stochastic risk, not hydraulic damage"
#######
####### dependencies:
#######   - file containing list of parameters (nominally parameters.csv)
#######   - a number of files, each containing the Helios-simulated PPFD timecourse for leaf NNNNNN (timeseries_leafNNNNNN.txt), beginning at 000000
#######   - file containing leaf numbers (w/o leading zeroes), x, y and z positions (not used here), and IR skyview factors,
#######     for each row in PPFD simulations (nominally helios_positions.txt)
#######   - analogous files with artificial leaves used to test effect of known sunfleck properties (artificial_leaf_positions.csv and artificial_leaf_ppfds.csv)
#######   - file containing list of times (hour, minute, second) in 1st 3 columns, for each row in PPFD simulations (nominally times.txt)
#######   - code assumes parameters file is in the same directory as this Julia code, and others are in subdirectories:
#######     "homo_spherical/" or "...hetero_erectophile/" etc. or "artificial_test_leaves/"
#######
####### information:
#######   - first run code under 'prepare for simulations',
#######     then run either simleaves() or crosstest(), or run sample code to simulate a single leaf
#######   - note: chunks of implementation code are enclosed in brackets to enable folding for ease of navigation; using
#######       CTRL-ENTER within those brackets will attempt to run all code between brackets. Select and run lines or groups of lines instead.
#######


## externals
begin
    include("c:/rootdir.jl") #contains code that defines a string, "rootdir", which contains the path to the directory in which the "risk" directory is located
    using DifferentialEquations
    using Plots
    using DataFrames
    using CSV
    using Dierckx
    using StaticArrays
    using Optim
    using Statistics
    using StatsBase
    using JLD2
    using Printf
end


## physical constants and control codes
begin
    const EPSLEAF = 0.98
    const SIGBOLTZ = 5.67e-8 #stefan-boltzmann constant, J m-2 s-1 K-4
    const CPA = 29.2 #heat capacity of air, J mol-1 K-1
    const LAMBDA = 44000.0 #latent heat of vaporization, J mol-1
    const RGAS = 0.0083144626 #gas constant, kJ mol-1 K-1 (for PS parameter T dependencies from Bernacchi etc)
    const KW = 4.184*18.01 #leaf heat capacitance per unit water content, J mol-1 K-1
    const KD = 1.5 #leaf heat capacitance per unit dry matter content, J g-1 K-1
    const PATM = 101325.0 #total atmospheric pressure, Pa
    const VW = 1.8e-5 #molar volume of water, m3 mol-1
    const ETA = 0.89e-9 #viscosity at 25C
    const RATCHET = 0.0 #0.0 for downwards ratcheting (irreversible) stem K; 1.0 to allow K to recover immediately wrt psi
    const LEAFRATCHET = 0.0 #0.0 for downwards ratcheting (irreversible) leaf K; 1.0 to allow K to recover immediately wrt psi
end


## struct to contain constant parameters
mutable struct PARAMETERS
    #parameters taken from file
    alpha_v_down::Float64 #relative negative rate of change of relative photosynthetic capacity, s-1
    alpha_v_up::Float64 #relative positive rate of change of relative photosynthetic capacity, s-1
    alpha_K::Float64 #rate of change of K per unit difference between target and actual K, s-1
    alpha_pi_down::Float64 #rate of change of GC pi gradient for decreases
    alpha_pi_up::Float64 #rate of change of GC pi gradient for increases
    ca::Float64 #ambient CO2 mole fraction (umol mol-1)
    chardim::Float64 #leaf characteristic dimension (m)
    chi::Float64 #scalar used in hydromechanical model for gsw, mol m-2 s-1 MPa-1
    elastance_stem::Float64 #stem hydraulic elastance (inverse of capacitance) (MPa)
    gmin::Float64 #minimum stomatal conductance, mol m-2 s-1
    Jm25::Float64 #Jmax at 25C and full induction, umol m-2 s-1 ### note, this is just a default that we override in the simulations
    Kmv::Float64 #Michaelis constant for response of relative Amax to PPFD, umol m-2 s-1
    Kleafmax25o::Float64 #default maximum leaf hydraulic conductance at 25C, mol m-2 s-1 MPa-1  ### note, this is just a default that we override in the simulations
    Kstemmax25o::Float64 #default maximum stem hydraulic conductance at 25C, mol m-2 s-1 MPa-1 ### note, this is just a default that we override in the simulations
    lma::Float64 #leaf dry mass per unit area, g m-2
    m::Float64 #epidermal mechanical advantage, unitless
    nleafmax::Float64 #leaf water content at zero water potential, mol m-2
    nstemmax::Float64 #leaf water content at zero water potential, mol m-2
    psi50leaf::Float64 #water potential (<0) resulting in 50% loss of hydraulic conductivity, MPa
    psi50stem::Float64 #water potential (<0) resulting in 50% loss of hydraulic conductivity, MPa
    pie::Float64 #epidermal osmotic pressure (>0) at zero water potential, MPa
    pio::Float64 #osmotic pressure (>0) at zero water potential, MPa
    psis::Float64 #soil water potential (<=0), MPa
    pwa::Float64 #atmospheric water vapor pressure (Pa)
    rtlp::Float64 #symplastic RWC at turgor loss point, unitless
    t_Tamax_hr::Float64 #time in hours (24-hr scale; 0 - 24) at which air temperature = Tamax
    Tamax::Float64 #diurnal maximum air temp, deg C
    Tamin::Float64 #diurnal minimum air temp, deg C
    thetaa::Float64 #curvature parameter for colimitation of photosynthesis by carbox and regen, unitless
    Vm25::Float64 #Vcmax at 25C and full induction, umol m-2 s-1 ### note, this is just a default that we override in the simulations
    vwind::Float64 #wind speed (m s-1)
    xiPLC::Float64 #steepness parameter for vulnerability curve, unitless

    #calculated or taken from source other than parameter file
    t_Tamax_sec::Float64 #time of Tamax, seconds
    gbw::Float64 #boundary layer conductance to water vapor, mol m-2 s-1
    fir::Float64 #IR skyview, unitless
    M::Float64 #net epidermal mechanical advantage, unitless ### = m-1
    Kleafmax25::Float64 #actual maximum leaf hydraulic conductance at 25C, mol m-2 s-1 MPa-1 ### adjusted in sims to be proportional to Vm25
    Kstemmax25::Float64 #actual maximum stem hydraulic conductance at 25C, mol m-2 s-1 MPa-1 ### adjusted in sims to be proportional to Vm25

    #imposed
    psi50_risk::Float64 #psi50 (<0) to use in risk for numerical gs model, MPa
    xi_risk::Float64 # steepness term for risk for numerical gs model, unitless
    KvsA::Int #whether or not to force Kmaxes to track Vcmax (0=no, 1=yes) ### default = yes; always yes for sims in ms
    f::Int #leaf number (1 - 10,000) (note numbers from Helios output are 0 - 9,999)
end


## struct to contain solution values
mutable struct SOLN
    t::Float64 #time (s)
    rleaf::Float64 #leaf RWC (unitless)
    psileaf::Float64 #leaf water potential (MPa) (<0)
    psistem::Float64 #stem water potential (MPa) (<0)
    Pleaf::Float64 #leaf turgor pressure (MPa)
    pileaf::Float64 #leaf osmotic pressure (MPa) (>0)
    Pg::Float64 #guard cell osmotic pressure (MPa)
    Pe::Float64 #epidermal osmotic pressure (MPa)
    gsw::Float64 #stomatal conductance to water vapor (mol m-2 s-1)
    deltaw::Float64 #leaf to air water vapor mole fraction difference (mol mol-1)
    E::Float64 #leaf transpiration rate (mol m-2 s-1)
    gswtarget::Float64 #optimal target value of gsw
    Atarget::Float64 #target value of A (umol m-2 s-1)
    Vm25::Float64 #RuBP carboxylation capacity at 25C (umol m-2 s-1)
    Vm::Float64 #actual Vm incl temperature effect (umol m-2 s-1)
    Jm::Float64 #actual maximum potential electron transport rate (umol m-2 s-1)
    J::Float64 #actual potential electron transport rate (umol m-2 s-1)
    Av::Float64 #A under carboxylation limited conditions (umol m-2 s-1)
    Aj::Float64 #A under regeneration limited conditions (umol m-2 s-1)
    A::Float64 #net CO2 assimilation rate (umol m-2 s-1)
    ci::Float64 #intercellular CO2 mole fraction (umol mol-1)
    ppfd::Float64 #incident photosynthetic photon flux density (umol m-2 s-1)
    T::Float64 #leaf temperature (deg C)
    nleaf::Float64 #leaf water content (mol m-2)
    nstem::Float64 #stem water content (mol m-2; leaf area basis)
    Kleaf::Float64 #leaf hydraulic conductance incl T effect (mol m-2 s-1 MPa-1)
    Kstem::Float64 #stem hydraulic conductance incl T effect (mol m-2 s-1 MPa-1)
    Amr::Float64 #relative induction state for Vm (unitless)
    dpi::Float64 #guard cell osmotic gradient (MPa)
    Kleaf25::Float64 #Kleaf at 25C (mol m-2 s-1 MPa-1)
    Kstem25::Float64 #Kstem at 25C (mol m-2 s-1 MPa-1)
end


## struct to hold photosynthesis-related outputs
mutable struct PS
    Vm25::Float64 #Vm at 25CF (umol m-2 s-1)
    Jm25::Float64 #Jm at 25C (umol m-2 s-1)
    Vm::Float64 #actual Vm (umol m-2 s-1)
    Jm::Float64 #actual Jm (umol m-2 s-1)
    J::Float64 #actual J (umol m-2 s-1)
    Rd::Float64 #rate of non-photorespiratory CO2 release (umol m-2 s-1)
    gams::Float64 #gamma star (photorespiratory CO2 compensation point) (umol mol-1)
    Kprime::Float64 #effective Michaelis constant for carboxylation (umol mol-1)
    Av::Float64 #A under carboxylation limited conditions (umol m-2 s-1)
    Aj::Float64 #A under regeneration limited conditions (umol m-2 s-1)
    civ::Float64 #ci under carboxylation limited conditions (umol mol-1)
    cij::Float64 #ci under regeneration limited conditions (umol mol-1)
    A::Float64 #assimilation rate (umol m-2 s-1)
    ci::Float64 #intercellular CO2 mole fraction (umol mol-1)
end


## function to create PARAMETERS structure of plant parameters
function get_parameters(filename::String)
  #main parameter file has parameter names in first column and values in 2nd column
  #load transposed so CSV.File object will have columns w/ para names
  f = DataFrame(CSV.File(filename, header=1, transpose=true))
  f = f[1,:] #converts first row from vec to scalar

  # load parameters from file
  alpha_v_down = f.alpha_v_down
  alpha_v_up = f.alpha_v_up
  alpha_K = f.alpha_K
  alpha_pi_down = f.alpha_pi_down
  alpha_pi_up = f.alpha_pi_up
  ca = f.ca
  chardim = f.chardim
  chi = f.chi
  elastance_stem = f.elastance_stem
  gmin = f.gmin
  Jm25 = f.Jm25
  Kmv = f.Kmv
  Kleafmax25o = f.Kleafmax25
  Kstemmax25o = f.Kstemmax25
  lma = f.lma
  m = f.m
  nleafmax = f.nleafmax
  nstemmax = f.nstemmax
  psi50leaf = f.psi50leaf
  psi50stem = f.psi50stem
  pie = f.pie
  pio = f.pio
  psisoil = f.psisoil
  pwa = f.pwa
  rtlp = f.rtlp
  t_Tamax_hr = f.t_Tamax_hr
  Tamax = f.Tamax
  Tamin = f.Tamin
  thetaa = f.thetaa
  Vm25 = f.Vm25
  vwind = f.vwind
  xiPLC = f.xiPLC

  #calculate other parameters
  t_Tamax_sec = 3600.0*t_Tamax_hr #convert input from hrs to seconds
  gbw = 1.08*0.267*(sqrt(vwind/chardim)) #boundary layer conductance for water vapor, whole-leaf; based on gbh = 6.62*sqrt(v/d) mm/s, PATM=1.01325*10^5 Pa and T=298.15 K
  fir = 0.78*exp(-0.78*2.5*0.225) #IR skyview ### default value, overridden by outputs from Helios ###this calc assumes  LAI of 2.5, sampled fraction = 70-75% of rel canopy height (so mean cum LAI above=0.225*LAI)
  M = m - 1.0 #net epidermal mechanical advantage (unitless)

  #imposed
  psi50_risk = psi50leaf #psi50 parameter for risk penalty; default value
  xi_risk = xiPLC #steepness parameter for risk penalty; default value
  KvsA = 1 #default (1=scale hydraulic conductances with photosynthetic capacities across leaves; 0=don't)
  Kleafmax25 = Kleafmax25o #set max values to inputs from file ### note, overridden later wrt PPFD/Vm
  Kstemmax25 = Kstemmax25o
  f = 1 #default (leaf number)

  #create PARAMETERS structure
  x = PARAMETERS(alpha_v_down, alpha_v_up, alpha_K, alpha_pi_down, alpha_pi_up, ca, chardim, chi, elastance_stem, gmin, Jm25, Kmv, Kleafmax25o,
                Kstemmax25o, lma, m, nleafmax, nstemmax, psi50leaf, psi50stem, pie, pio, psisoil, pwa, rtlp, t_Tamax_hr, Tamax, Tamin, thetaa, Vm25, vwind, xiPLC,
                t_Tamax_sec, gbw, fir, M, Kleafmax25, Kstemmax25, psi50_risk, xi_risk, KvsA, f)

  return(x)
end #end get_parameters()


## function to calculate target value of stomatal conductance (and associated assimilation rate)
function target_gasx(T::Float64, Kplant::Float64, Amr::Float64, deltaw::Float64, ppfd::Float64, p::PARAMETERS)

    #optimize() here adjusts candidate value of gsw (gsw_) to maximize output of function PSrisk()
    # function looks between gmin and gsw_=2.0 mol m-2 s-1
    o = optimize(gsw_ -> -PSrisk(gsw_, T, Kplant, Amr, deltaw, ppfd, p), p.gmin, 2.0, GoldenSection())
    gsw = o.minimizer #get optimized result
    A = photosynthesis(gsw, ppfd, T, Amr, p).A #calculate A
    gsw = (A >= 0.0) ? gsw : p.gmin #set gsw to its minimum if A < 0

    return([gsw, A]) #return vector containing optimized target values
end #end gtarget_()


## function to return goal function
function PSrisk(gsw::Float64, T::Float64, Kplant::Float64, Amr::Float64, deltaw::Float64, ppfd::Float64, p::PARAMETERS)

    A = photosynthesis(gsw, ppfd, T, Amr, p).A
    A = (A>=0.0) ? A : 0.0
    gtw = gsw*p.gbw/(gsw + p.gbw) #total conductance to water vapor
    psiss = p.psis - gtw*deltaw/Kplant #theoretical steady-state water potential for this conductance
    if (p.psi50_risk < 0.0) && (p.xi_risk > 0.0)
        if psiss < p.psis #I think this if() is unnecessary bc gsw is floored at gmin in leaf() below
            r = 1.0 - 1.0/(1.0 + (psiss/p.psi50_risk)^p.xi_risk) #'r' here is as in Eller model; r*A = Theta
        else
            r = 0.0
        end
    else
        r = 1.0
    end

    return((1.0 - r)*A) #return value is A - Theta == A*(1 - r)
end


## function for system of ODEs
function leaf(u, p, t)
    # this function takes a vector (u) of current state variables, as well as the parameters structure (p) and time (t),
    #  and returns a vector containing the derivatives of each state variable with respect to time
    dpi = u[1] #guard cell osmotic gradient (guard cell osmotic pressure minus epidermal osmotic pressure) (>0)
    T = u[2] #leaf temperature
    nleaf = u[3] #leaf water content
    nstem = u[4] #stem water content
    Kleaf25 = u[5] #leaf hydraulic conductance at 25C
    Kstem25 = u[6] #stem hydraulic conductance at 25C
    Amr = u[7] #relative induction state of carboxylation capacity
    ppfd = PPFD[p.f](t) #get PPFD timecourse; these are loaded in from files in a different section of code

    Tac = Ta(t) #air temp in deg C; Ta(t) is a function created before running any sims, at the same time PPFD timecourses are loaded in
    TAK = Tac + 273.15 #Tair in kelvins
    TK = T + 273.15 #Tleaf in kelvins
    Kleaf = Kleaf25*((TK/298.15)^7.0) #correct Kleaf for temperature
    Kstem = Kstem25*((TAK/298.15)^7.0) #correct Kstem for temperature
    psistem = p.elastance_stem*(nstem/p.nstemmax - 1.0) #calculate stem water potential (elastance is d{psistem}/d{RWCstem})
    psistem = (psistem <= 0.0) ? psistem : 0.0 #cap psistem at zero

    k = KW*nleaf + KD*p.lma #leaf heat capacitance, J m-2 K-1; KW and KD are constants defined earlier
    rleaf = nleaf/p.nleafmax #leaf relative water content
    Pleaf = p.pio*(rleaf - p.rtlp)/(1.0 - p.rtlp) #leaf turgor pressure; pio is osmotic pressure at full turgor
    Pleaf = (Pleaf >= 0.0) ? Pleaf : 0.0 #floor Pleaf at zero
    pileaf = p.pio/rleaf #leaf osmotic pressure (>0)
    psileaf = Pleaf - pileaf #leaf water potential
    psileaf = (psileaf <= 0.0) ? psileaf : 0.0 #cap psileaf at zero
    pie = p.pie/rleaf #epidermal osmotic pressure
    Pg = psileaf + pie + dpi #guard cell turgor pressure
    Pe = psileaf + pie #epidermal turgor pressure
    Pg = (Pg >= 0.0) ? Pg : 0.0 #floor Pg and Pe at zero
    Pe = (Pe >= 0.0) ? Pe : 0.0
    gsw = p.chi*(Pg - p.m*Pe) #stomatal conductance from hydromechanical model
    gsw = (gsw >= p.gmin) ? gsw : p.gmin #floor gsw at theoretical minimum value
    deltaw = (611.2*exp(17.62*T/(243.12 + T)) - p.pwa)/PATM #leaf to air H2O mole fraction diff; mol mol-1; pwa and PATM are in Pa
    deltaw = (deltaw >= 0.0) ? deltaw : 0.0 #floor deltaw at zero
    E = deltaw*(gsw*p.gbw)/(gsw + p.gbw) #leaf transpiration rate

    #calculate target value of stomatal conductance; target_gasx() returns a vector that also includes A at the target value
    target = target_gasx(T, Kleaf*Kstem/(Kleaf + Kstem), Amr, deltaw, ppfd, p) ## 2nd argument is plant hydraulic conductance
    gswtarget = target[1]
    ddpi = (gswtarget - gsw)/p.chi #GC osmotic gradient equivalent to gswtarget
    alpha_pi = (ddpi > 0.0) ? p.alpha_pi_up : p.alpha_pi_down #determine value of GC osmotic adjustment time constant (upwards or downwards)
    ddpidt = alpha_pi*ddpi #derivative of dpi wrt time

    Fleaf = Kleaf*(psistem - psileaf) #flow of water into leaf
    dnleafdt = Fleaf - E #rate of change of leaf water content is flow in minus transpiration

    dnstemdt = Kstem*(p.psis - psistem) - Fleaf #rate of change of stem WC is flow from soil minus flow into leaf

    eps_atm = 0.642*((p.pwa/TAK)^(1.0/7.0)) #emissivity of sky if not cloudy; pwa is in Pa and TAK is in kelvins

    #leaf energy balance. 0.3116 is total shortwave energy flux per unit PPFD; fir is IR skyview from Helios
    dTdt = (0.3116*ppfd + p.fir*SIGBOLTZ*(eps_atm*(TAK^4.0) - EPSLEAF*(TK^4.0)) - CPA*(p.gbw/1.08)*(T - Tac) - LAMBDA*E)/k

    Kleaf25ss = p.Kleafmax25/(1.0 + (psileaf/p.psi50leaf)^p.xiPLC) #theoretical steady-state leaf K
    dKleaf25 = (Kleaf25ss < Kleaf25) ? (Kleaf25ss - Kleaf25) : LEAFRATCHET*(Kleaf25ss - Kleaf25) #ratchet=0 means only downward changes are possible
    dKleaf25dt = p.alpha_K*dKleaf25

    Kstem25ss = p.Kstemmax25/(1.0 + (psistem/p.psi50stem)^p.xiPLC) #likewise for stem K
    dKstem25 = (Kstem25ss < Kstem25) ? (Kstem25ss - Kstem25) : RATCHET*(Kstem25ss - Kstem25) #ratchet=0 means only downward changes are possible
    dKstem25dt = p.alpha_K*dKstem25

    Amrtarget = ppfd/(ppfd + p.Kmv) #Amr is relative induction state for Vm; Amrtarget is the theoretical steady state value of this induction state
    dAmr = Amrtarget - Amr #difference between target and actual
    alpha_v = (dAmr > 0.0) ? p.alpha_v_up : p.alpha_v_down #induction and de-induction have different time constants
    dAmrdt = alpha_v*dAmr #derivative of Amr wrt time

    #using static arrays to optimize; see https://tutorials.sciml.ai/html/introduction/03-optimizing_diffeq_code.html
    #  note: must give ODEProblem() initial conditions in the form of a static array
    @SVector [ddpidt, dTdt, dnleafdt, dnstemdt, dKleaf25dt, dKstem25dt, dAmrdt]
end #end leaf()


## function to get timecourses for all states from solution
function get_all_states(sol)

    ti = convert(Int, floor(minimum(sol.t))) #get initial and final time of solution
    tf = convert(Int, floor(maximum(sol.t)))
    nsteps = convert(Int, floor((tf - ti)/10) + 1) #determine number of time steps for 10-s resolution
    x = Array{SOLN}(undef, nsteps) #create array to hold results
    i=0 #step counter
    for t in ti : 10 : tf #loop through the timesteps
        i += 1
        ppfd = PPFD[p.f](t)

        #state variables
        dpi = sol(t)[1]
        T = sol(t)[2]
        nleaf = sol(t)[3]
        nstem = sol(t)[4]
        Kleaf25 = sol(t)[5]
        Kstem25 = sol(t)[6]
        Amr = sol(t)[7]

        #other quantities derived from state variables; same calcs as in leaf()
        Tac = Ta(t)
        TAK = Tac + 273.15
        TK = T + 273.15
        Kleaf = Kleaf25*((TK/298.15)^7.0)
        Kstem = Kstem25*((TAK/298.15)^7.0)
        psistem = p.elastance_stem*(nstem/p.nstemmax - 1.0)

        rleaf = nleaf/p.nleafmax
        Pleaf = p.pio*(rleaf - p.rtlp)/(1.0 - p.rtlp)
        Pleaf = (Pleaf >= 0.0) ? Pleaf : 0.0
        pileaf = p.pio/rleaf
        psileaf = Pleaf - pileaf
        pie = p.pie/rleaf
        Pg = psileaf + pie + dpi
        Pe = psileaf + pie
        Pg = (Pg >= 0.0) ? Pg : 0.0
        Pe = (Pe >= 0.0) ? Pe : 0.0
        gsw = p.chi*(Pg - p.m*Pe)
        gsw = (gsw >= 0.0) ? gsw : 0.0
        deltaw = (611.2*exp(17.62*T/(243.12 + T)) - p.pwa)/PATM #mol mol-1; pwa is in Pa
        deltaw = (deltaw >= 0.0) ? deltaw : 0.0
        E = deltaw*(gsw*p.gbw)/(gsw + p.gbw)

        target = target_gasx(T, Kleaf*Kstem/(Kleaf + Kstem), Amr, deltaw, ppfd, p)
        gswtarget = target[1]
        Atarget = photosynthesis(gswtarget, ppfd, T, Amr, p).A

        ps = photosynthesis(gsw, ppfd, T, Amr, p)

        x[i] = SOLN(1.0*t/3600.0, rleaf, psileaf, psistem, Pleaf, pileaf, Pg, Pe, gsw, deltaw, E, gswtarget, Atarget,
                            ps.Vm25, ps.Vm, ps.Jm, ps.J, ps.Av, ps.Aj, ps.A, ps.ci, ppfd,
                            T, nleaf, nstem, Kleaf, Kstem, Amr, dpi, Kleaf25, Kstem25)
    end

    return x
end


## function to calculate photosynthesis given g, PPFD and T
function photosynthesis(gsw::Float64, ppfd::Float64, T::Float64, Amr::Float64, p::PARAMETERS)

    Vm25 = Amr*p.Vm25 #adjust Vm25 for relative induction state
    Jm25 = p.Jm25

    #temperature-dependent photosynthetic parameters
    TleafK = T + 273.15
    iRT = 1.0/(RGAS*TleafK) #one over R*T
    Vm = Vm25*exp(26.35 - 65.33*iRT) #max carbox rate
    Jm = Jm25*exp(17.57 - 43.54*iRT) #max potential e- tpt rate
    Kc = exp(38.28 - 80.99*iRT) #Michaelis constant for carboxylation
    iKo = exp(-14.68 + 23.72*iRT)  #1/Ko; one over the Michaelis const for oxygenation
    Kprime = Kc*(1.0 + 210.0*iKo) #effective Michaelis constant for carboxylation; oxygen is in ppt
    gams = exp(13.49 - 24.46*iRT) #photorespiratory CO2 compensation point
    Rd = (0.0089*p.Vm25)*exp(18.72 - 46.39*iRT) #non-photorespiratory CO2 release, 0.0089 is from de Pury & Farquhar
    phiPSII = 0.352 + 0.022*T - 3.4e-4*T*T #electrons per photon
    thetaj = 0.76 + 0.018*T - 3.7e-4*T*T #unitless curvature parameter

    #potential e- tpt rate
    phiji = phiPSII*0.9*0.5*ppfd #0.9 is assumed leaf absorptivity to PPFD
    bj = -(Jm + phiji)
    cj = Jm*phiji
    det = bj*bj - 4.0*thetaj*cj
    J = (det>=0.0) ? ((-bj - sqrt(det))/(2.0*thetaj)) : 0.0 #hyperbolic minimum

    gtc = gsw*p.gbw/(1.37*gsw + 1.6*p.gbw) #total conductance to CO2

    bciv = Vm - Rd - gtc*(p.ca - Kprime)
    cciv = -(Vm*gams + Rd*Kprime + gtc*p.ca*Kprime)
    det = bciv*bciv - 4.0*gtc*cciv
    civ = (det>=0.0) ? ((-bciv + sqrt(det))/(2.0*gtc)) : (Vm*gams + Rd*Kprime)/(Vm - Rd) ## value if det<0 is compensation point

    bcij = 0.25*J - Rd - gtc*(p.ca - 2.0*gams)
    ccij = -(0.25*J*gams + Rd*2.0*gams + gtc*p.ca*2.0*gams)
    det = bcij*bcij - 4.0*gtc*ccij
    cij = (det>=0.0) ? ((-bcij + sqrt(det))/(2.0*gtc)) : (0.25*J*gams + Rd*2.0*gams)/(0.25*J - Rd)

    Av = Vm*(civ - gams)/(civ + Kprime) - Rd
    Aj = 0.25*J*(cij - gams)/(cij + 2.0*gams) - Rd

    #smoothing V- and J-lim versions w/ hyperbolic minimum
    A = ((-(-Av-Aj) - sqrt((-Av-Aj)*(-Av-Aj) - 4.0*p.thetaa*Av*Aj))/(2.0*p.thetaa))
    ci = (gtc > 0.0) ? p.ca - A/gtc : p.ca

    return PS(Vm25, Jm25, Vm, Jm, J, Rd, gams, Kprime, Av, Aj, civ, cij, A, ci)
end


## function to simulate a number of leaves and return an array containing the solutions
function simleaves(p, L1, L2, resultsdf)
    #p is parameter structure, L1 and L2 are leaf numbers of first and last leaves to be simulated, resultsdf is a dataframe to hold the results
    u0 = @SVector [p.M*p.pie, p.Tamin, p.nleafmax, p.nstemmax, p.Kleafmax25, p.Kstemmax25, 1.0] #initial condition
    tspan = [sunrise + 100, sunset - 100] #time span

    for L in L1:L2
        #same stuff as in simleaf()
        p.f = leaves.leafnum[L] #leaf number
        p.fir = leaves.skyview[L] #IR skyview factor
        ibar = leaves.meanPPFD[L] #mean PPFD
        p.Vm25 = 100.0*ibar/400.0 #adjust Vm25 to be proportional to mean PPFD
        p.Jm25 = 2.1*p.Vm25
        if p.KvsA == 1 #same for hydraulic conductances
            p.Kleafmax25 = p.Kleafmax25o*p.Vm25/100.0
            p.Kstemmax25 = p.Kstemmax25o*p.Vm25/100.0
        else
        end
        prob = ODEProblem(leaf, u0, tspan, p) #define problem
        sol = solve(prob) #solve problem
        # if soln is unstable, it will exit solve() before end of tspan
        if maximum(sol.t) == tspan[2]
            z = get_all_states(sol)
            resultsdf[L,:] = z #return entire solution
        else
        end
    end
end


## function to test effect of given range of values of psi50_risk on many leaves
function crosstest!(P50range, p, L1, L2, mA, mE, mY)
    #P50range is an input range of values for psi50risk; p is parameter structure; L1, L2 are first and last leaves in set to simulate;
    #  mA, mE, mY are vectors to hold mean A, mean E, and min leaf psi from sim results
    for L in L1:L2 #loop through leaves
        pii = 0 #loop counter
        for pp in P50range #loop through psi50risk values for each leaf
            pii += 1
            p.psi50_risk = pp
            p.f = leaves.leafnum[L] #leaf number
            p.fir = leaves.skyview[L] #IR skyview
            ibar = leaves.meanPPFD[L] #mean PPFD
            p.Vm25 = 100.0*ibar/400.0 #adjust Vm25 to be proportional to mean PPFD across leaves
            p.Jm25 = 2.1*p.Vm25
            if p.KvsA == 1 #same for hydraulic conductances
                p.Kleafmax25 = p.Kleafmax25o*p.Vm25/100.0
                p.Kstemmax25 = p.Kstemmax25o*p.Vm25/100.0
            else
            end
            u0 = @SVector [p.M*p.pie, p.Tamin, p.nleafmax, p.nstemmax, p.Kleafmax25, p.Kstemmax25, 1.0] #initial condition
            tspan = [sunrise + 100, sunset - 100] #time span
            prob = ODEProblem(leaf, u0, tspan, p) #define problem
            sol = solve(prob) #solve problem
            # if soln is unstable, it will exit solve() before end of tspan
            if maximum(sol.t) == tspan[2]
                z = get_all_states(sol); ns = length(z)
                za = [z[s].A for s in 1:ns]; za = za[.!isnan.(za)]; mA[L,pii] = mean(za) #calculate and return mean A
                ze = [z[s].E for s in 1:ns]; ze = ze[.!isnan.(ze)]; mE[L,pii] = mean(ze) #mean E
                zy = [z[s].psileaf for s in 1:ns]; zy = zy[.!isnan.(zy)]; mY[L,pii] = minimum(zy) #minimum leaf psi
            else
            end
        end
        print(L)
    end
end


## prepare for simulations - load in PPFD timecourses, create functions of PPFD and air temp vs time
{
    #choose a leaf distribution
    ##### note: only run one of the following five lines of code
    lightdirname = rootdir * "risk/homo_spherical/"; canopy="HO" #homogeneous canopy with spherical leaf angle distribution (most sims)
    lightdirname = rootdir * "risk/hetero_spherical/"; canopy="HS" #heterogeneous, spherical (heterogeneous = clumped into spherical crowns)
    lightdirname = rootdir * "risk/hetero_planophile/"; canopy="HP" #heterogeneous, planophile
    lightdirname = rootdir * "risk/hetero_erectophile/"; canopy="HE" #heterogeneous, erectophile
    lightdirname = rootdir * "risk/artificial_test_leaves/"; canopy="AT" #artificial PPFD timecourses used to test effect of known sunfleck properties on min psileaf

    # load in parameters
    parafilename = rootdir * "risk/parameters.csv"
    p = get_parameters(parafilename)

    # load in times for Helios simulations
    t = DataFrame(CSV.File(lightdirname * "times.txt", header=0, transpose=false))
    tm = t[:,1]*3600.00 + t[:,2]*60.0 + t[:,3] #create timestamp (sec into day)

    # generate function for air T vs time
    sunrise = minimum(tm) #5 am
    sunset = maximum(tm) #9 pm
    Ta(t) = p.Tamin + (p.Tamax - p.Tamin)*sin(0.5*pi*(t - sunrise)/(p.t_Tamax_sec - sunrise))

    # load in positions and skyviews
    if canopy != "AT" #load in list of leaf positions (also includes skyview factor, fir)
        psv = DataFrame(CSV.File(lightdirname * "helios_positions.txt", header=0, transpose=false)) #output from Helios
    else
        psv = DataFrame(CSV.File(lightdirname * "artificial_leaf_positions.csv", header=0, transpose=false)) #created by hand
    end

    # generate functions for PPFD vs time for each leaf
    leaves = psv #create new structure using psv as template
    nf = nrow(leaves) #get number of leaves
    PPFD = Vector{Spline1D}(undef, nf) #create vector to contain spline functions for each leaf
    leaves.meanPPFD = [1.0 : 1.0 : 1.0*nf;] #create column for mean PPFD (values generated here are meaningless)
    if canopy != "AT" #for Helios output,...
        rename!(leaves, Symbol.(["leafnum", "nothing", "xpos", "ypos", "zpos", "skyview", "meanPPFD"])) #give columns meaningful names; 2nd col is empty bc of extra space in positions file
        @elapsed for f in 1:nf #loop through all leaves; @elapsed returns elapsed time for this loop
            ftext = lpad(leaves.leafnum[f], 6, "0") #generate string w/ leading zeroes to construct filename of this leaf's PPFD timecourse
            ppfd = DataFrame(CSV.File(lightdirname * "timeseries_leaf" * ftext * ".txt", header=0, transpose=false))
            leaves.leafnum[f] = leaves.leafnum[f] + 1 #leafnum = f in 1-10,000 (Helios output uses 0 - 9,999)
            PPFD[f] = Spline1D(tm, ppfd[:,1]) #generate continuous spline function, needed for ODE solver
            leaves.meanPPFD[f] = mean(ppfd[:,1]) #calculate mean PPFD
        end
    else #same as above but for artificial leaves used to test effect of known sunflecks on minimum psileaf
        rename!(leaves, Symbol.(["leafnum", "jump", "duration", "zpos", "skyview", "meanPPFD"]))
        ppfds = DataFrame(CSV.File(lightdirname * "artificial_leaf_ppfds.csv", header=0, transpose=false))
        for f in 1:nf
            leaves.leafnum[f] = leaves.leafnum[f] + 1 #now leafnum = f in 1-10,000
            PPFD[f] = Spline1D(tm, ppfds[3:5762,f])
            leaves.meanPPFD[f] = mean(ppfds[3:5762,f])
            leaves.jump[f] = ppfds[1,f]
            leaves.duration[f] = ppfds[2,f]
        end
    end

    ##### note: don't try to save the spline functions -- it creates a gigantic file (GBs) that will take longer to reload than it does to recreate the splines

    allleaves = leaves #save backup
    nrow(allleaves)

    ## done with setup, ready to run some simulations
}


## sample code for simulating a leaf
{
    p = get_parameters(parafilename) #load in parameters
    L=10 #choose a leaf; note, sequence of leaf numbers doesn't mean anything, they were randomly sampled
    p.f = leaves.leafnum[L] #get actual leaf number
    p.fir = leaves.skyview[L] #get IR skyview
    ibar = leaves.meanPPFD[L] #get mean PPFD
    p.Vm25 = 100.0*ibar/400.0 #adjust Vm25 and Jm25 to track mean PPFD across leaves
    p.Jm25 = 2.1*p.Vm25
    if p.KvsA == 1 #same for hydraulic conductances
        p.Kleafmax25 = p.Kleafmax25o*p.Vm25/100.0
        p.Kstemmax25 = p.Kstemmax25o*p.Vm25/100.0
    else
    end

    #set up and solve coupled ODE problem
    u0 = @SVector [p.M*p.pie, p.Tamin, p.nleafmax, p.nstemmax, p.Kleafmax25, p.Kstemmax25, 1.0] #initial condition
    tspan = [sunrise + 100, sunset - 100] #time span
    prob = ODEProblem(leaf, u0, tspan, p) #define problem
    sol = solve(prob) #solve problem
    x = get_all_states(sol) #get all states
    ns = length(x) #get number of time steps in interpolated solution

    ##### sample plots
    plot([x[s].t for s in 1:ns], [x[s].ppfd for s in 1:ns], xlabel="time", ylabel="PPFD", legend=false)
    plot([x[s].t for s in 1:ns], [x[s].gswtarget for s in 1:ns], label="target", xlabel="time", ylabel="stomatal conductance")
    plot!([x[s].t for s in 1:ns], [x[s].gsw for s in 1:ns], label="actual") #plot!() updates existing plot
}


## examine effect of varying psi50_risk across cohort of leaves
{
    #max and min psi50risk; note, the sims in the ms originally used a range of -2.0 to -3.5, with 15 steps;
    # this was later extended by adding sims from -3.5 to -4.5 with 6 steps and discarding the first step (at -3.5).
    # So the spacing of steps will be different from that used in the ms if using the code exactly as shown here.
    P50los = [-2.0, -2.0, -2.0, -2.0, -2.0] #5 values are given for option to do 5 sets of simulations, e.g., multiple canopies or other assumptions
    P50his = [-4.5, -4.5, -4.5, -4.5, -4.5]
    # cs = [1,2,3,4,5]

    cs = [1] # by default we're just doing one set
    sample_all_PPFD = false
    NF = 500

    for c in cs

        leaves=allleaves
        if sample_all_PPFD == true
            nf = nrow(leaves) #do sims for every leaf in 'leaves' df
        else
            # specify which leaves to use
            fi=1
            ff=NF
            nf = ff - fi + 1
        end

        p = get_parameters(parafilename)
        stomspeed_mult = 1.0 #optional factor to adjust the stomatal response speed parameter
        watermass_mult = 1.0 #optional factor to adjust the leaf water content at saturation

        p.alpha_pi_up *= stomspeed_mult; p.alpha_pi_down = p.alpha_pi_up; #adjust stomatal response speed
        p.nleafmax *= watermass_mult #adjust leaf absolute water content

        # generate vector of psi50risk values
        p_lo = P50los[c]
        p_hi = P50his[c]
        p_steps = 20
        psi50_risk_ = [p_lo : (p_hi - p_lo)/(p_steps - 1.0) : p_hi; ]

        # generate arrays to hold results
        meanA = Array{Float64}(undef, nf, length(psi50_risk_))
        meanE = Array{Float64}(undef, nf, length(psi50_risk_))
        minpsi = Array{Float64}(undef, nf, length(psi50_risk_))

        # run simulations. Warning, this may take a very long time if you're running many leaves x many psi50risk values
        # suggest you run it with just a few and note the elapsed time
        @elapsed crosstest!(psi50_risk_, p, fi, ff, meanA, meanE, minpsi)

        #create a string to be used in filename for output
        tag = rootdir * "risk/" *   "ss" * string(stomspeed_mult) *
                                    "_wm" * string(watermass_mult) * "_" *
                                    canopy * "_fi_" * string(fi) * "_ff_" * string(ff) * "_" * string(p_steps)

        # output results to file
        CSV.write(tag * "A.csv", DataFrame(meanA))
        CSV.write(tag * "E.csv", DataFrame(meanE))
        CSV.write(tag * "Y.csv", DataFrame(minpsi))
    end
}


## sensitivity analysis
{
    p = get_parameters(parafilename)

    #just use a single value of psi50_risk_
    psi50_risk_ = [-2.0; ]

    #use first 500 leaves (they are in a random order; the sequence doesn't mean anything)
    leaves=allleaves
    fi=1
    ff=500

    #create arrays to hold results
    meanA = Array{Float64}(undef, ff, 1); mA = Array{Float64}(undef, ff, 5) #5 is number of diff values for each parameter; =high index for lohi below
    meanE = Array{Float64}(undef, ff, 1); mE = Array{Float64}(undef, ff, 5)
    minpsi = Array{Float64}(undef, ff, 1); mY = Array{Float64}(undef, ff, 5)

    pnames = fieldnames(typeof(p)) #get parameter names

    pns = [1:32] #create vector of parameter numbers; can substitute individual params here and modify code below to reproduce different ranges used for m and psisoil

    for pn in pns  #loop through the parameters
        if (pnames[pn]==:Jm25 || pnames[pn]==:Vm25 || pnames[pn]==:nleafmax || pnames[pn]==:psi50leaf || pnames[pn]==:vwind || pnames[pn]==:thetaa)
            #don't do sensitivity analysis for these parameters
        else
            paraname = string(pnames[pn]) #get string containing name of parameter
            for lohi = 1:5 #loop through five values of the parameter
                mult = [0.75, 0.99, 1.0, 1.01, 1.25][lohi] #multiplier for default parameter values: 75%, 99% etc
                LOHI = ["075","099","100","101","125"][lohi] #strings to use in filenames
                p = get_parameters(parafilename) #load default parameter values (to override changes made in previous runs of the loop)

                #Rtlp and characteristic dimension need to be handled slightly differently
                if pnames[pn]!=:rtlp || pnames[pn]!=:chardim
                    setfield!(p,pnames[pn],mult*getfield(p, pnames[pn])) #modify value of parameter #pn
                else
                    p.rtlp = pnames[pn]==:rtlp ? 1.0 - mult*(1.0 - p.rtlp) : p.rtlp #adjust relative water loss at TLP rather than RWC at TLP
                    p.gbw = pnames[pn]==:chardim ? mult*p.gbw : p.gbw #we actually just want to adjust gbw, not chardim per se
                end
                #correct values of paras that are only calculated once, in get_parameters()
                p.t_Tamax_sec = 3600.0*p.t_Tamax_hr

                #run simulations
                crosstest!(psi50_risk_, p, fi, ff, meanA, meanE, minpsi) #run simulations for leaves # fi to ff
                mA[:,lohi] = meanA; mE[:,lohi]= meanE; mY[:,lohi] = minpsi #record outputs
            end #end for lohi
            #write results to file
            tag = rootdir * "risk/sensitivity analysis/" * paraname * canopy * "_fi_" * string(fi) * "_ff_" * string(ff) #create most of filename
            CSV.write(tag * "A.csv", DataFrame(mA)); CSV.write(tag * "E.csv", DataFrame(mE)); CSV.write(tag * "Y.csv", DataFrame(mY)) #save results
        end #end if pnames
    end #end for pn
}


## simulations for artificial test leaves, with known, exact sunfleck properties, to see how sunflecks affect minimum leaf water potential
{
    rd = Array{SOLN}(undef, nf, ns) #create array to hold results
    simleaves(p, 1, nf, rd) #simulate all leaves

    #generate arrays to hold minimum leaf psi and info about the sunflecks
    minpsi = Array{Float64}(undef, nf)
    flecks = Array{Float64}(undef, nf, 4)

    #loop through the leaves, populate the results arrays
    for L in 1:nf
        minpsi[L] = minimum([rd[L,s].psileaf for s in 1:ns]) #calculate minimum leaf psi over the day for this leaf
        flecks[L,1] = leaves.jump[L] #record the jump size (step size for PPFD); was in input in the 'positions' file for these artificial leaves
        flecks[L,2] = leaves.duration[L] #record the sunfleck duration
        flecks[L,3] = log(flecks[L,1]*(leaves.duration[L] <= 30 ? leaves.duration[L] : 30)) #record the composite sunfleck "strength"
        flecks[L,4] = minpsi[L] #put min psi into this vector
    end

    write results to file
    CSV.write(rootdir * "risk/artificial_test_leaves/flecks.csv", DataFrame(flecks))
}
